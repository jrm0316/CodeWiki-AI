def conectar():
    return "conectado"
